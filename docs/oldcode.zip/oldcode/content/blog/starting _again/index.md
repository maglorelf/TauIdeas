---
title: Starting again
date: "2021-11-26T00:50:00.000Z"
description: "First entry in my new site"
templateKey: 'blog-post'
---

After several years I start a new website with the objetive of show my hidden work to the world.

This site is made with Gastby !(Gatsby.js)[Gatsbyjs.com]. It's my first project full in javascript.
