---
title: Migration of servers
date: "2022-06-28T00:50:00.000Z"
description: "Migrate old windows servers to linux servers"
templateKey: 'blog-post'
---

The .NET ecosystem is currently evolving to new versions. Currently, with .NET 6 and the public availability of .NET MAUI these days, my servers are obsolete. I have a virtual machine with an IIS installed. But the cost is very high for non-profit projects. 

The next month's objective is to migrate my servers to Linux. Today I'm going to study the options I have:

* Create a VM with Linux with a webserver to install my applications on it.
* Use a Linux hosting prepared to deploy .NET apps.
* Deploy in the cloud docker images (for example, Azure, AWS, etc.)

I have a lot of old projects in different environments: Windows Forms, Web, and Mobile. The migration requires an upgrade to .NET 6, in the Xamarin projects the logical migration is the new .NET MAUI.

Of course, several projects don't go to be migrated. Maybe the knowledge was unnecessary and I'm going to close completly the repository.
