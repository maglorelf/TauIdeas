---
title: Tauideas
creation-date: "2021-12-02T00:50:00.000Z"
date: "2021-12-02T00:50:00.000Z"
description: A blog to show my personal portfolio and some technical articles
templateKey: 'project-page'
projectcode: 
website: https://www.tauideas.tech/
repository: https://github.com/maglorelf/TauIdeas
---
# Brief #
The Tauideas website will be for my use as a technical blog and portfolio. It starts with the minimum content and must be grown with adding content.

The be some sections: blog, project portfolio. Other sections will be added in the future.

# Technology
The project is created with Gatsby front end. It allows creating static pages from markdown files. I use the basic template https://www.gatsbyjs.com/starters/gatsbyjs/gatsby-starter-blog/.

Gatsby cloud allows a deployment directly from the Github repository.

All the code it's done with Node.js, React and Markdown.
