---
title: Giftsteer
creation-date: "2021-12-02T00:50:00.000Z"
date: "2021-12-02T00:50:00.000Z"
description: A simple app to create your wish list for a event (birthday, chritsmas, wedding). Have a Secret santa function.
templateKey: 'project-page'
projectcode: 
website: http://www.giftsteer.tauideas.tech/
repository: 
---
# Brief #
Giftsteer allows publish your wish list of presents to your family and friends to give them some ideas for the presents.
We have a Secret Santa funtion with a simple lottery between your friends.

 http://www.giftsteer.tauideas.tech/

# Technology
* ASP.NET MVC 5
* .Net Framework 4.6
